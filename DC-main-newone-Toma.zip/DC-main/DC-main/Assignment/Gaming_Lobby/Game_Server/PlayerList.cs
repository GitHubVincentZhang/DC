﻿using PlayerDLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Server
{
    public class PlayerList
    {
        public static List<Player> Players()
        {
            List<Player> plist = new List<Player>();

            // Creating sample players
            Player player1 = new Player();
            player1.Name = "Robert";
            player1.GameTag = "RobFighter";
            player1.Id = 101;
            player1.Username = "Robert007";

            Player player2 = new Player();
            player2.Name = "Mia";
            player2.GameTag = "MiaCombo";
            player2.Id = 102;
            player2.Username = "MiaMia";

            Player player3 = new Player();
            player3.Name = "Adam";
            player3.GameTag = "AdamSlasher";
            player3.Id = 103;
            player3.Username = "SlashingAdam";

            Player player4 = new Player();
            player4.Name = "Sophia";
            player4.GameTag = "SophiaBlade";
            player4.Id = 104;
            player4.Username = "SophiaGod";

            Player player5 = new Player();
            player5.Name = "Ethan";
            player5.GameTag = "EthanThunder";
            player5.Id = 105;
            player5.Username = "GreatThunder";

            // Adding players to the list
            plist.Add(player1);
            plist.Add(player2);
            plist.Add(player3);
            plist.Add(player4);
            plist.Add(player5);

            return plist;
        }

        public static bool IsUserNameAvailable(string username)
        {
            List<Player> playerList = Players(); //retrive
            //Console.WriteLine("Checking username: " + username);
            foreach (Player player in playerList)
            {
                //Console.WriteLine("Existing username: " + player.Username);
                if (player.Username.Equals(username, StringComparison.OrdinalIgnoreCase))
                {
                    return false; //username not available
                }
            }
            return true; // the username is avialble
        }
    }
}
